package com.example.trabajofinalgrupo6dbpapplication.model

data class CitaMedica(
    val id: Int,
    val especialidad: String,
    val medico: String,
    val fecha: String,
    val hora: String,
    val observaciones : String?,
    val estado: String
)

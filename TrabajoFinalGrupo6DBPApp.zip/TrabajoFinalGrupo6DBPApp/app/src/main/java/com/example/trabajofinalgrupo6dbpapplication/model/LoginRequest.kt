package com.example.trabajofinalgrupo6dbpapplication.model

data class LoginRequest(
    val correo: String,
    val contrasenia: String
)

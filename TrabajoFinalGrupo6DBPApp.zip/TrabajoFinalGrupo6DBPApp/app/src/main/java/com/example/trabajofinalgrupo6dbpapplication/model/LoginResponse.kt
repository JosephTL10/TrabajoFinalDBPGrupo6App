package com.example.trabajofinalgrupo6dbpapplication.model

import com.google.gson.annotations.SerializedName

data class LoginResponse(
    @SerializedName("id") val id: Int,
    @SerializedName("nombreCompleto") val nombre: String,
    @SerializedName("dni") val dni: String,
    @SerializedName("correo") val correo: String,
    @SerializedName("telefono") val telefono: String,
    @SerializedName("fechaNacimiento") val fechaNacimiento: String,
    @SerializedName("direccion") val direccion: String
)

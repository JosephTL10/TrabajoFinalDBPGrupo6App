package com.example.trabajofinalgrupo6dbpapplication.model

data class Paciente(
    val id: Int,
    val nombre: String,
    val dni: String,
    val correo: String,
    val telefono: String,
    val fechaNacimiento: String,
    val direccion: String
)

package com.example.trabajofinalgrupo6dbpapplication.network

import com.example.trabajofinalgrupo6dbpapplication.model.CitaMedica
import com.example.trabajofinalgrupo6dbpapplication.model.LoginRequest
import com.example.trabajofinalgrupo6dbpapplication.model.LoginResponse
import retrofit2.http.POST
import retrofit2.http.GET
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Body
import retrofit2.Response
import okhttp3.ResponseBody


interface ApiService {

    @POST("api/pacientes/login")
    suspend fun login(@Body loginRequest: LoginRequest): Response<LoginResponse>

    @GET("api/pacientes/{id}/citas")
    suspend fun getCitas(@Path("id") id: Int): Response<List<CitaMedica>>

    @PUT("api/citas/{id}/cancelar")
    suspend fun cancelar(@Path("id") id: Int): Response<ResponseBody>

    @PUT("api/citas/{id}/confirmar")
    suspend fun confirmar(@Path("id") id: Int): Response<ResponseBody>
}
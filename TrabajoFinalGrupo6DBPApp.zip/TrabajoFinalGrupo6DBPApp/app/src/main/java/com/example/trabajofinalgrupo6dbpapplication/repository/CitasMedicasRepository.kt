package com.example.trabajofinalgrupo6dbpapplication.repository

import com.example.trabajofinalgrupo6dbpapplication.network.RetrofitClient

class CitasMedicasRepository {
    private val api = RetrofitClient.instance

    suspend fun getCitas(id: Int) =
        api.getCitas(id)

    suspend fun cancelarCita(id: Int) =
        api.cancelar(id)


    suspend fun confirmarCita(id: Int) =
        api.confirmar(id)


}

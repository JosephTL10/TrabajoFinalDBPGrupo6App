package com.example.trabajofinalgrupo6dbpapplication.repository

import com.example.trabajofinalgrupo6dbpapplication.model.LoginRequest
import com.example.trabajofinalgrupo6dbpapplication.network.RetrofitClient

class PacienteRepository {
    private val api = RetrofitClient.instance

    suspend fun login(correo: String, contrasenia: String) =
        api.login(LoginRequest(correo, contrasenia))
}

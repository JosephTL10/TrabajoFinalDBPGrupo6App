package com.example.trabajofinalgrupo6dbpapplication.ui


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.trabajofinalgrupo6dbpapplication.R
import com.example.trabajofinalgrupo6dbpapplication.model.CitaMedica

class CitaMedicaAdapter(
    private val lista: List<CitaMedica>,
    private val onCancelar: (Int) -> Unit,
    private val onConfirmar: (Int) -> Unit
)
    : RecyclerView.Adapter<CitaMedicaAdapter.CitaViewHolder>() {

    class CitaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val esp: TextView = view.findViewById(R.id.txtEspecialidad)
        val med: TextView = view.findViewById(R.id.txtMedico)
        val fecha: TextView = view.findViewById(R.id.txtFecha)
        val hora: TextView = view.findViewById(R.id.txtHora)
        val estado: TextView = view.findViewById(R.id.txtEstado)
        val btnCancelar: Button = view.findViewById(R.id.btnCancelar)

        val btnConfirmar: Button = view.findViewById(R.id.btnConfirmar)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CitaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cita, parent, false)
        return CitaViewHolder(view)
    }

    override fun onBindViewHolder(holder: CitaViewHolder, position: Int) {
        val c = lista[position]

        holder.esp.text = c.especialidad
        holder.med.text = "Médico: ${c.medico}"
        holder.fecha.text = "Fecha: ${c.fecha}"
        holder.hora.text = "Hora: ${c.hora}"
        holder.estado.text = "Estado: ${c.estado}"

        holder.btnCancelar.setOnClickListener {
            onCancelar(c.id)
        }

        holder.btnConfirmar.setOnClickListener {
            onConfirmar(c.id)
        }
    }

    override fun getItemCount(): Int = lista.size
}

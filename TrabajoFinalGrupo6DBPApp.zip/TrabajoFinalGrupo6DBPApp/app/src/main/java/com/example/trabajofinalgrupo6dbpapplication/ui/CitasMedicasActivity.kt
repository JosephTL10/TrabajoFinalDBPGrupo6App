package com.example.trabajofinalgrupo6dbpapplication.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.trabajofinalgrupo6dbpapplication.R
import com.example.trabajofinalgrupo6dbpapplication.repository.CitasMedicasRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CitasMedicasActivity : AppCompatActivity() {

    private val repo = CitasMedicasRepository()

    private lateinit var rv: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.lyt_citas_medicas)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        rv = findViewById(R.id.rvCitas)
        rv.layoutManager = LinearLayoutManager(this)

        val idPaciente = intent.getIntExtra("pacienteId", 0)

        cargarCitas(idPaciente)
    }

    private fun cargarCitas(idPaciente: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            val response = repo.getCitas(idPaciente)

            if (response.isSuccessful) {
                val lista = response.body()!!

                runOnUiThread {
                    rv.adapter = CitaMedicaAdapter(
                        lista,
                        onCancelar = { idCita -> cancelarCita(idCita) },
                        onConfirmar = { idCita -> confirmarCita(idCita) }
                    )
                }
            } else {
                runOnUiThread {
                    Toast.makeText(
                        this@CitasMedicasActivity,
                        "Error al cargar citas",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun cancelarCita(idCita: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            val response = repo.cancelarCita(idCita)

            runOnUiThread {
                if (response.isSuccessful) {
                    Toast.makeText(
                        this@CitasMedicasActivity,
                        "Cita cancelada",
                        Toast.LENGTH_SHORT
                    ).show()
                    recreate()
                } else {
                    Toast.makeText(
                        this@CitasMedicasActivity,
                        "Error al cancelar",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun confirmarCita(idCita: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            val response = repo.confirmarCita(idCita)

            runOnUiThread {
                if (response.isSuccessful) {
                    Toast.makeText(
                        this@CitasMedicasActivity,
                        "Cita confirmada",
                        Toast.LENGTH_SHORT
                    ).show()
                    recreate()
                } else {
                    Toast.makeText(
                        this@CitasMedicasActivity,
                        "Error al confirmar",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
}

package com.example.trabajofinalgrupo6dbpapplication.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.trabajofinalgrupo6dbpapplication.R
import com.example.trabajofinalgrupo6dbpapplication.repository.PacienteRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    lateinit var edtCorreoPaciente : EditText
    lateinit var edtContrasenaPaciente : EditText
    lateinit var btnIniciarSesionPaciente : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        asignarReferencias()
    }

    private fun asignarReferencias() {
        edtCorreoPaciente = findViewById(R.id.edtCorreoPaciente)
        edtContrasenaPaciente = findViewById(R.id.edtContrasenaPaciente)
        btnIniciarSesionPaciente = findViewById(R.id.btnIniciarSesionPaciente)

        btnIniciarSesionPaciente.setOnClickListener {
            validarCampos()
        }


    }

    private fun validarCampos() {
        val correo = edtCorreoPaciente.text.toString().trim()
        val contrasena = edtContrasenaPaciente.text.toString().trim()

        if (correo.isEmpty()) {
            edtCorreoPaciente.error = "El correo es obligatorio"
            return
        }

        if (contrasena.isEmpty()) {
            edtContrasenaPaciente.error = "La contraseña es obligatoria"
            return
        }


        iniciarSesion(correo, contrasena)
    }


    private fun iniciarSesion(correo: String, contrasena: String) {
        val repo = PacienteRepository()

        CoroutineScope(Dispatchers.IO).launch {
            val response = repo.login(correo, contrasena)

            runOnUiThread {
                if (response.isSuccessful) {
                    val paciente = response.body()

                    Toast.makeText(this@MainActivity, "Bienvenido ${paciente?.nombre}", Toast.LENGTH_LONG).show()

                    // Luego abre la pantalla de citas
                    val intent = Intent(this@MainActivity, CitasMedicasActivity::class.java)
                    intent.putExtra("pacienteId", paciente?.id ?: 0)
                    startActivity(intent)
                } else {
                    Toast.makeText(this@MainActivity, "Correo o contraseña incorrectos", Toast.LENGTH_LONG).show()
                }
            }
        }
    }






}